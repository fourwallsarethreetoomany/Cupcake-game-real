import pygame
import base64
import io
import random
import asyncio


pygame.init()
WIDTH = 500
HEIGHT = 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Cupcake Collector")




clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 36)




JUMP_COOLDOWN = 500  # ms
last_jump_time = 0
 
 
GRAVITY = 0.5
JUMP_STRENGTH = -10




BASE64_SPRITE = (
    "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAqAMBEQACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAABgQFAgMHAQj/xAA/EAABAwMCAwQIBAMIAgMAAAABAgMEAAUREiEGMUETIlFhBxQyQnGBkaEVI7HBYoLRJDNDUnKS0vA0whdTZP/EABoBAQADAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAwEQACAgEEAQQABAUFAQAAAAAAAQIRAwQSITFBBRMiUTJCYXEjUoGRoTNDscHRFP/aAAwDAQACEQMRAD8A7jQBQBQBQBQBQBQGDjiW0lS1JSkcyo4FCG0uyD+NQTNYhoeDj76SptKASCkcznljcVNFfcjuUfJnc7imA02pQSpbrgabBUEjUQTuTyGxokJzUSFIv/qMOVJuMRbSWCgJ7NYcDxVsAg7ZOcDfH70oo8tJtm9F1fTKjxpUB1pb4UUKSpK0jAyQT0NKLKbumjGLxBAkR1vl0sttudmtT6SgJUCQRk7cx40oiOWMlZZtOJdQFtqStChkKScg1BrZnQBQBQBQBQBQBQBQBQBQBQBQGmVJYix1vyXUNNIGVLWrAA+NCG0lbKeVeg+9a2ITvZpuOtSH1J91Iz3QepztnpmrUYyy24qPkrZqW5yblw9cnnJL6mnHmH32QgIGMDSdgrB6gUX2ZzaleOXZEamSJ0OwXdpapb7DoDkaKzkoCkaVhWM4xkHcjlU/oUTbjGS7QyXyK5cITLIgsy2VuAvsSMDKMHl4EHFVR05I71VWUDnCKhGfTa44gth5h9qK48VpK21aieunUMDbwzU2YPT8fHjovnZNy1l9MBxLTbSvysoU44s4xjfAA367+FRwbuU+6FRbLsbh612yTIcbcnSUCUy80EhOpZU53sDYnPMnORVvJybWscYPy+S7tvrFzm3KQ7KdiwIjyo8ZlhWgDR7S1eO/Q7bVBtDdJybdJGdn4nYetsIy1rcmSEqUhtlorWtAUQF6UjYEAHwo0Wx54uKvsv40lqS0HWFhaCSMjoRzB8DVTdNPo3UJCgCgCgCgCgCgCgCgK293iNZ43bydRBIAAH3J6AZ3JqUrM8mRY1bKVVyVAvy0XOQiTBlaUIdSjDcZee6hXMd7Oyue3wqaMfc2z+XKZDYsy3n3LWyHRBivJlW+4NEf2YnJKBn2gD4bYOOlTfkosVvZ4XKYys2dtT6ZM9aZclKdCVqbCQlO+QAOWc71WzpWPm5cssENpbSEoASkckgYAqC6SXRnQkKA8IzQGKkBQwrBHgRQUVk2yRpQfSpx9puQcvttOaUu/Hw+WM1JnLEpWVkZhrh+fcpS4b7nbaExvV2VLw0lIAbGBtvk7+NT2YqKxNuv2IcKTdIiW4jSEm8z5SpjzBOURmT0WR5ADbmfgaUUjKa+K/E+f2Q5NFRQCtISogagDkA/GqnaZ0AUAUAUAUAUAUBCu01UGE480yp90JJQyjms/wDedSkVnLarN2lqXFw6lDjbqO8kjKVAj9KgUpLkoLVYHGo0m1zQ27aA4ewZUnKinIOFHO4znbmRzqzZhDC6cX0MbbaUJCUJCUjYADAFVOlcGdAFAFAFAVN/4gt1gj9rcHwhSvYaTutZ8h+9Sk2Y5c8MSuTOY3r0mXaYpSLahEFo7A41ufU7D6VooLyeVl9QyS/BwUkfijidTpeZuc9wp3VglaR8RyqdsTCOp1D5TZ1DgDipXEkJ1qYEJmx8a9A2cSeSsfXas5Ro9bSan3o89onos8i2y3HLN2CG5SwXy8CpTYAxlPiOmk7DPyqL+zX23F3HybbhfTHuKbbAiOTZxSFuNoUEpZSfeWo8vhzpXFkzy1LbFWyfAm+tBaVtll9pWl1okHScZG45gjfNQaRlZMoWCgCgCgCgMVKASSeQG9AKxjQL/NS5NcnRJqQpLLQfWyoN59pOMZ1DBPPw6Va6OXZHK7laZr4bs6lPIfVNuRjxVraDT0gqbdUlWAseQxy8aNkYcXN2+BuKgASeQ5mqnWVb/ElkjuFt66xELHQuip2syefGu5G2Je7VMOmLcIzqvBDoJpTJWXHLpk/IqDQMigFPjfjFjhxnsGAl64uJyhsnZA/zK/p1q0Y2ceq1UcKpdnGJ02Vc5apEt1b8hw4ydyfAAfsK24R4c5yyyt9nQeEPRwXUomcQhSQcFMQHB/nP7Cs3P6PS02g/Nk/sdKiwo0KOliKw0yykYCEIAArNs9OMIxVJHP8AhyOm3elO6xY6dDDjSl6ByGdKv1JrR8xODDHZqpJHSDWZ6RR3FuZbHpk2A3EX6yUlfrDpbCFABIOQDkYA2qUYyUo24lFbLq5DfeRFWq8XBT4eubzCfymUAY0pyegGwGTkHxqzRzwybXSdvyOzLqHm0uNqCkKSFJI5EGqHanas2UJCgCgCgKLiqWw1ETGdvTdqW6rZ0qAXjyz54qUYZmttOVFE1ZokmXFjXM3KY46e0afRPUpkge+MEaem2OuxNWsxWKLkt1t/uO6EBKABnaqHauBBubc3jXiCZbGpS4tnt5CHlNnvPOdRV+kefNS1GRwTqKN//wAXWDRpDk5Jx7Xap/44pvZL9Pw/qVNw9FA0lVtuZJHJMhH7j+lSshjP03+RlItvjTg/v6pHq6OoV2zOP2H0qfizBrVaf9hha9I8lPDa5kuG03LWrs42lXddI5qxzAHx57VGw6Vr37VyXJzKS+/MkuPyXFvPuqypStyomtOjyHKU5W+zrPo+4JTa0IuV1bCp6hlts7hkf8v0rKUrPZ0ekUFvmuR9Aqh6IHlQCJw+n1n0mX+SndMdpLWfMhP9DV30cGL5amT+h8qh3muQw3JZcZeQFtOJKVpPJQPMUIaTVMq2+HIDSI4bQtJjMFlgpUBoB5kADGrYbmpszWGK6J0CNHgx24kUBLTKdKU6skCoLxSSpEqhYKAKAKAV7jMbtl2lKuludfiStPZyWmC8EgDBQoDcb5PhvVjmnJRk9y4ZM4YjR2kSnILC2ITrmthpaCjGw1EJO6QT0+fWoZfDGKtxXBeVBsJvASfVLlxHAc/vkXAu78ylQyDV5dI49Ktspx/Ucaodh7QEK73CNbLc/NlqCWWk6lefl86ldmeScYQcpdHz9e7o9d7i7MdSlAUcIaSMJbR0SBW6VI+czZHkk2y0tbL1gtzHELkIuuOOYiB1BLaAOa1fHkkfE1Xvg3xxeKPutWdS4T4zt3ESQ2k+rzQMqjrUN/NJ6is3Gj1sGqjlX6jODtVTqPFqCElROw3NA3QnejdovsXa7rHenznFJOPcBIH6mrSfg4tGr3T+2OdVO0KAqb3lCoby33Wozb+XyhWAU4ONX8OcZqUZ5PDF3hlqQp1UtmOXVKuj5MsnT2jG+DvuobjHTapZz4b7/Udx5VU7D2gCgItykiFAkylDIZaUv6DNCsnUWxC/GHEdq0xxEG+2aC3U3ZhYUle/dbHdO/hk4wPGr0cLyPxLv7/6H63NrahR23XS84lpIU6oYKzjnVWd0L28kmoLClxEyuzXlniWOhSmAjsLghPVrOzn8p+1WXKo5cqcJrKv6jQ08240HULSptSdQWDsR45qp07lV+CkunGVhtpKH57bjv8A9bH5ivtU7WYT1OKHbOeek7iU3KQzbo2tthkBx5CsZ7Qj2T/p/WtIRo83X6je9i6FWzw2pDrj8zIgxUdo+Qd1dAgeajt9auzjxwUuX0izkccX99kx/WWm4+MBlMdGkJ8NxyqqijWWtyvjpEFviG6NLS40+htaTlKkxmwQf9tTRktRkTtMnI464mSci7LI8FNIP/rTYjT/AO3P/MS0+kXiDslNPuRn21DSoLawSDz3SRUbEaLX5aplnYPSS3a4jMJVmQiM0MJ7B45HyVz+tQ4GuL1BQSi48DvZuOLFdiltqWGHlbBqQNBJ8jyNUcWjvx6vFk6YyJOoZFVOo1S+0TFeUyAXQ2ooB6nG1Csrp0KLNmtX4ebrKucx+SlAWqT60sFtXkgHA32048qvbOVYYVub5Gm0vrk2yI+57bjKFK2xuQM/eqM6oO4pkuhYKAr77KMS2POp7IKwEpLx7gJIAKvIZyalFMktsWxXVcJ01XYzZNmlx2nm2nUN51PhRHeRv3cZ5b5xUnNulJ8tDuKqdgEgczQCNxT6QrdbQuLAQm4SPZWM/lJ8ievwFXUGzgz66EPjHlnMpV6utzQ3CbccTHRs3DiJIQkeASOfzrSkeW82XJwv8E232GdaWjebrCUzEjjW2l3A7Vz3E454zgnyFRfgtDDOH8SS4QvOOLedW64rWtaipR8VHc1ZHM7kzrNl4ItzfCzCb2443qV6zIAd0AEjYKP8I+5NZOTvg9nFpILEt5UqlejeI72aYj0kDbtAlak/cjNT8jHfo4uqGix2rgq8sdrbYEJ4J5gt95PxB3qrbR14oabIrijVxPwdHMIu2G2W1MhsElpyMlQcHgD0NSn9lc+mW28cVYi8PO2eddkW6/WyHDUXCkrQhTZ1Y9g97unPWrv7RwYnCU9mSNDrM9GFjeGYzsqMrppXqH3qm9nbL07FLrgVrx6MbrFQpy3vtTkD3MaFn5Hb71ZTRyZPTpx5g7NPCvGNy4bmJgXbtlwgoJW08DrY8xnp5fSjin0Rg1WTDLbPo7M04h5lLjagpC0hSVDqDWR7aaatC1FY4hV26o6rSxqeWO0UypS1gKIBVggZxVuDnSyvqi6syZTdvbbnupekoKgtxPJXeP0+HSoZtjTUUpdk6oLhQEebFYmM9jJbDjeQopVyODkZ+dCsoqSplTKtnDrLsZT0a3x3u1SphQShKioKBGk8zvU2zJ48Sq0XnSoNzk/HHF0u8T1WOwdopkq7Namc6n1dQP4f1+FaRjXLPI1Wqlkl7WMl8Oei9JSl+/PHJ3EZlXL/AFK/pRz+i2D09d5DoFvs9vtrHYwYbDLZGDpQMkeZ5mqWejHFCCpI5d6UpDcR2LYoi19gxl9aCsq0lXspHkBnbzrSH2eV6hKmsaKX0f2b8Y4ljocRqjsfnO/Ach8zj71M3SOfR4vcyq+kMXpevDyp7FnbUUsJaDzgHvqJOAfIAfeqwXk6vUcrtY10c6rU8ksuHbtIst3jzYyyNKgHE52WjPeB+VVkrN9PleOaaPocuoDRcKsICdRJ6DGawPpb4s57xDwg5xJbV3hkdncXFKdbbIwFte6k+eADnxJrSMqPOz6X3Y712e+jjixx9X4FeFqEtrKGFuc145oP8QxSUfKGj1Tf8OfZ0MnbArM9I5p6Y2IQagPJSkT1uFPd9pTeN8/A4x8a0hZ5XqMY0q7HThGNIicM22PLBDyI6QoHmny+Q2qj5Z34E1iimLRt6JEl91h+anTMeXMCZ62Q2nUoAhP0Oeu9WOf21J2rGbhRLabOkMuOOt9s7occJKljWrBJPPPjVX2dOFVHguKg1CgKziRoPWKclSdQDClafHAzj7VKM8quDFZx+4yWJRiWa5KiraSYyJHZNpZxvlKRueQx1qxy7pu/i6GDiyY7H4TuMqPkOiMSk43TnbPyqq7N88msLkvoW/RPZY8ezG6qSFSZKlJSo+4gHGB9M1ab8HN6fhSx7/LH/FUPQBRwM0B878Tzzc+IbhLJyFvqCf8ASNh9gK3XR8zqJ78rZ0z0Q2v1ayPz3E/mS3O6f4E7D75NZzfJ63p+Pbj3fZS+l+zPJnsXltJLCmwy6QPYUCcfUH7VMH4MPUcTtTXRzk1qeSWXDtpfvd3jwo6SdSgXFY2QjO5qsnRvgxPJNJHernGXKjNw0Adi4oJfOf8AD6j58vnWJ9HKNraTwgDAHIch4VBc596SeFy4DfrSFNzGcKeSjYrA5KH8Q+4q8X4PN1un/wB2PaNtt42n3KyRTa7Wubc15bdxs00sY7yj4EHIptSZaGrlOC2RuRLsXB7xuP4zxLIE25HdCB/ds+GB1xRy8Ivi0z3b8vLHEkBJJIAA3Jqh2iU3eJbSTFsUtV4kJUdeGAWWySScu5AA+pq9HF7rXxxu2NtsEr1Bgz1NmUU5d7P2Qo7kDyHKqs64XtV9kqoLBQGKxkEYoBUfVf30oRLmxrfFU6pla2W8uEDIByrupzgdDzq3ByP3X26RZWgRJ9jVAEkTWGgqK44CO+AMdOe2Kh9msKnBq7Fvh6U5wW+5Zb5lFvU4Vw5+Py8H3VH3T8as1uOXC3pn7c+vDHxp1t5AW04laDuFJOQfnVDvTT6IV/lCHZJ8oH+5jOLHySaldlMstuOTPnIZUQBus8vM1ufMds+jbBCFts0KEn/BYQknxON/vWDfJ9PijsxqJLkMtSG1svtpcbWMKSoZBHnUF2k1TFKR6N+HXnu0Qy+yOqG3jp+9X3s45aDC3dFtAiWDhaIUNKiwkH2lOujUr4knJqvLNoRw4VS4MHOKIazpt0ebcF9PVmDp/wB5wn70oPOvyqzSt7im4bRosO1NH35C+2cH8qdvvU8FW88vwqjFjhBt2Q3JvVwmXOQ2oLR2rmhtJ8kJ2pu+gtPzc3ZQQIp4U9IYisjFuuyCUJ6JVzx8jn/dU9xOaEXg1FLqR0UVQ9Ig3aQ4ywluMhC5D6+ybDnsZIOSfIAE/KpRSbaVIVlWyWxIEa62+EmPMJaTMthW0ptahtqTnkeWc+FWs5ts06kuH9Dq0kNtJQOSQAKodaVcGdCQoAoBVvNrtv40l64xzJRKOdLzmlhrQO8ognBJGOnu1ZNnLkxw33Lz/Y22u729VzbjWaIVQnQUuSmWSGtYA0gHkdgdx4UaJhkjuqC4GF5lt9tTbyErQrYpUMg1U6Gk1TKgcK2lpWqG07DP/wCR9bQ+iTj7VNmXsQX4eCv4vhmBwfd9MqS/qYx+e5rxv0+tTHsz1EduGXJxywsiTfbcyrcOSmwf9wrWXR4WCN5Io+jQMVgfTkWZFfkLBanPR0gbpbSk5+ZBqSsot+SKqxx3P/KkzZHkuSsD6JIH2pZX20+yLbYtqFzksQbXHCY4AdkBAP5h30cskgYJPmKFYxhuaSLxIAAAqDUzoSFAKvGDCZF14cSj/wAhM/UMc9ASSo/DYVaPRy5184V3Y0ZxVTqFTiGe+ZmpMUybewsIWlp3Q8Xspwpv/MU5xgHqRVkjlyzd9WkS7bKavlxLzEt5UeLjXEdjlBbdxtknfIGTjzB8KPgtCSyStPheBhFVOg9oAoAoCtvtsbutvXHWhtSgoLb7VGpIUDkZHUdCPA1NlMkN0aNC7i3Z2Y7NyVgrwA60wQ0CTy2zpx50qyu5Y0lItmlpcQlaFBSVDIIOQRUGpnQFJxqwZHCl1bT7Xqy1AeOBn9qmPZhqVeKSOJcJrSjie0rPIS2/1FbS6PB03+tE+hxWB9Ke0BRcR3d6MWrbbAly6y9mUnk2nq4ryH3NSl5MM2RqoR7ZPs9uatdvaiMFSggZUtR7zijuVHzJo3ZpjgoR2oiu2qUypS7ZcnWMnPZPjtm8/M6h8jQq8cvys0OSuJ45x+GwJoHvNSi0T/KpJ/WnBRyzLwmaF3Lit46GLDEjE/4r84LA/lSMmppEb87/AC/5JNlsr0eYu5XeUJlxcRoCwjShlH+VA6eZ5mjf0Wx4mnvm7ZdqwASdh1JqpuL7EGBcYLz1tbaOqQpxsO5UlLqVkFScHKSSOYPnUmCjGUbiWloiuRY39pUlcl1RcfWkbFZ8PIDAHkKM0hHauSdUFwoAoAoAoDRNjolx1MuFaQr3kKwpJ8QfGhWUdyopLNIkQJJts8y3dyWn3GgUqBO3eTtv5gVLMsbcXtZdMTY8h15lpwKcYVpcRyKTzG371BqpJukbHm0vNLaWAULSUqB6g0JatUfPN5gSOH7+9GPdcjPBTSj1GcpNbp2j5vLB4ctfR3HhziGDfLa1KYeQHNI7VoqwW1dQRWLVHvYc8ckE0Qr7xdFhOCDa0i4XVzZqM0cgHxUrkBUqP2Vy6hR+MeWSOGbI7b+1nXJ4SbrKOX3uiR0QjwSKhsnDicflLlsvqg6AoAoAoDArTnTkaiMgUFlBeZciZNFrt50utrYddXoJwjXk+HRP3qUYZJOT2IuLdCagRG47A7icnJ5kk5JPmSTUGsYqKpEqhYKAKAKAKAKA8IzQFXxDKnw4DjtriokP4xhSvZ/iwNyBzIG9Sv1M8spqNxViy5Be4fhPTZTqErbkJV64hJMiUVEahjkc+yE/PbFW7Oba8Udzf/rGeJdHFOtNToi4a3klTYWsKBwMkEjkcb4qtHSp9WqshcU8K2/iVlHrOpqQ2Py328ZHkc8xUqTRnn00M65FBr0Tnt8vXX8rPuM4Vj4k4q284o+m0/xDtw7wza+H2CiAye0Oy3lnK1fP9htVHKzuw6eGJfEuqg3CgCgPFKCRkkAdc0BVXS8eqFDcZDT762lupbLoTrSn2tJ6n/uamjOc665F6U5NlTGH4L1tZaf/ALS3NkEqcbAAy3jltn/NyztUnO3OTW2qGWzJ7ZgTnmwmU+kBxSQQFAZAIB5DrjzqGdMOVufZZVBcKAKAKAKAKAKAKAKArLzblThEcbCFOxZAfQhZwlRAIwT05/UCpRnkhuqvAu8QouX511mstNJYaMeBF16yXXcI1rPLG/IdM1Ko582/mb/oWDUZ60NWm0Wt/wDOOS6p7LgKEp7xO+RuRjGOdDRRcFGEXyexeJUqcubUmMsKgHJLW4dRkgqTnHIgjHlSiY5uWn4J/wCOQ0yBHcL7b5b7Xs1MKzo5Z2BqKL+7G6Njl8tjZaSZrRU8nW2EnUVjxGOdKJ9yP2aXOILensglxxwuu9ikIaVu5jOnfkceNKKvNBG+DdGJsiRGQHG5DGC4y4MKAPI+YPjUNFo5FJtFJMkXGY5cYLiWEvxXmpTTS1dx1jqknHPKVdPCrGEpTla+v+CPbmJLz838NEVEecyiS02oa22iSAoHb3kjO3XfenBEYybbXTLy2WZqM7LddYY1SXg8WkpyhCgkAEZHPbntUNm0MSTb+y2FQantAFAFAFAFAFAFAFAFAFAapMdqUwtiQ2lxpYwpChsRQhpNUyGxaWYSXlwBpkLQEhx9a3cAchurON+QqbKLGo9dlE9w5MK7OoLa1tEszVJUQHmidecHrqHL+I1NmLwyuL+uyQp9TPFsqW5EmdgiEhlC0R1qC1BairGB/pp4JtrK21xRRNR5cAWRt/1iNIUuU64WWC76ul3UUg4BG2QPlUmKi47V55LCYl+RZU+qQpC5MWZHWhRZUkvqQEald4DYgFOTUGk+YfFdMuIcJ13iF66uNFhBjCOlCiCpXe1ajjl4fWoZrGL372SnrS09dG7g466HGmy2lKFaQQSCc457ill3jTluZNbZbaGG0JTvk6U43qCySRsoSFAFAFAFAFAFAFAFAFAFAFAFAFAeYHhQBgUAYFAGB4UAAAdKA9oAoAoAoAoAoAoAoD//2Q=="
)




try:
    image_data = base64.b64decode(BASE64_SPRITE)
    image_file = io.BytesIO(image_data)
    sprite_surface = pygame.image.load(image_file).convert_alpha()
except Exception as e:
    print(f"Error loading image: {e}")
    sprite_surface = pygame.Surface((50, 50))
    sprite_surface.fill((255, 0, 0))




class Platform:
    def __init__(self, x, y, width, height, color):
        self.rect = pygame.Rect(x, y, width, height)
        self.color = color
       
    def draw(self):
        pygame.draw.rect(screen, self.color, self.rect)




class Cupcake(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((24, 24), pygame.SRCALPHA)
        pygame.draw.circle(self.image, (255, 105, 180), (12, 12), 12)
        pygame.draw.rect(self.image, (200, 150, 100), (0, 13, 24, 12))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
       
    def draw(self):
        screen.blit(self.image, self.rect)




class Player(pygame.sprite.Sprite):
    def __init__(self, surface, player_x, player_y, player_dx):
        super().__init__()
        self.image = surface
        self.rect = self.image.get_rect()
        self.rect.x = player_x
        self.rect.y = player_y
        self.player_dx = player_dx
        self.velocity_y = 0
        self.is_grounded = False
       
    def update_physics(self, platforms):
        self.velocity_y += GRAVITY
        self.rect.y += self.velocity_y
        self.is_grounded = False
       
        for platform in platforms:
            if self.rect.colliderect(platform.rect) and self.velocity_y > 0:
                if self.rect.bottom - self.velocity_y <= platform.rect.top + 10:
                    self.rect.bottom = platform.rect.top
                    self.velocity_y = 0
                    self.is_grounded = True
                   
        if self.rect.bottom >= HEIGHT:
            self.rect.bottom = HEIGHT
            self.velocity_y = 0
            self.is_grounded = True
           
    def draw(self):
        screen.blit(self.image, self.rect)
       
    def right(self):
        self.rect.x += self.player_dx
        if self.rect.x > WIDTH - self.rect.width:
            self.rect.x = WIDTH - self.rect.width
           
    def left(self):
        self.rect.x -= self.player_dx
        if self.rect.x < 0:
            self.rect.x = 0
           
    def jump(self):
        if self.is_grounded:
            self.velocity_y = JUMP_STRENGTH
            self.is_grounded = False




def spawn_cupcake(platforms):
 
    # 20% chance to spawn on the ground
    if random.random() < 0.2:
        x = random.randint(0, WIDTH - 24)
        y = HEIGHT - 24
    else:
        # or on a random platform
        platform = random.choice(platforms)
        x = random.randint(platform.rect.left, platform.rect.right - 24)
        y = platform.rect.top - random.randint(24,60)
    return Cupcake(x, y)








player = Player(sprite_surface, 200, 150, 5)




platforms = [
    Platform(50, 400, 150, 20, (255, 180, 100)),
    Platform(250, 300, 150, 20, (100, 255, 100)),
    Platform(100, 200, 120, 20, (152, 200, 100)),
    Platform(350, 120, 100, 20, (100, 200, 255))
]




#  5 (for now) cupcakes
cupcakes = [
    Cupcake(100, 360),
    Cupcake(300, 260),
    Cupcake(150, 160),
    Cupcake(380, 80),
    Cupcake(random.randint(0, WIDTH - 24), HEIGHT - 24)  
]


async def main():
    score = 0
    can_jump = True
    running = True




    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
           
        keys = pygame.key.get_pressed()
        current_time = pygame.time.get_ticks()
   
        if not can_jump and (current_time - last_jump_time >= JUMP_COOLDOWN):
            can_jump = True
       
        if (keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP]) and can_jump:
            if player.is_grounded:
                player.jump()
                can_jump = False
                last_jump_time = current_time
           
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            player.left()
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            player.right()
       
        player.update_physics(platforms)
   
    # check collisions and respawn
        for cupcake in cupcakes[:]:
            if player.rect.colliderect(cupcake.rect):
                cupcakes.remove(cupcake)
                score += 1
                # add a new one when one is eaten
                cupcakes.append(spawn_cupcake(platforms))
           
        screen.fill((30, 30, 40))
   
        for platform in platforms:
            platform.draw()
       
        for cupcake in cupcakes:
            cupcake.draw()
       
        player.draw()
   
        score_text = font.render(f"Score: {score}", True, (0, 255, 255))
        screen.blit(score_text, (10, 10))
   
        pygame.display.flip()
        clock.tick(96)
        await asyncio.sleep(0)
   
    pygame.quit()
asyncio.run(main())











